
import telebot
import time
import random
from google_sheets import get_daily_post
from config import TOKEN
from telebot import types

bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=['start'])
def start(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add(types.KeyboardButton('Полный ГАЗ!'), types.KeyboardButton('Прогресс'))
    bot.send_message(message.chat.id, "🔥 Сельский Кочка на связи! Полный ГАЗ!", reply_markup=markup)

@bot.message_handler(func=lambda message: True)
def handle_message(message):
    if message.text == 'Полный ГАЗ!':
        audio_path = 'audio/lightweight.mp3'
        bot.send_audio(message.chat.id, open(audio_path, 'rb'))
        bot.send_message(message.chat.id, random.choice(["ЕБАШЬ!", "LIGHT WEIGHT BABY!", "ДАВИ!"]))
    elif message.text == 'Прогресс':
        content = get_daily_post()
        bot.send_message(message.chat.id, content)

print("Бот запущен...")
bot.polling(none_stop=True)
