
import gspread
from oauth2client.service_account import ServiceAccountCredentials

scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
creds = ServiceAccountCredentials.from_json_keyfile_name("credentials.json", scope)
client = gspread.authorize(creds)

sheet = client.open_by_url('YOUR_GOOGLE_SHEET_URL').sheet1

def get_daily_post():
    values = sheet.get_all_values()
    return values[-1][0]  # Последний пост
