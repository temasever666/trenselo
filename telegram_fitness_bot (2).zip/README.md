
# Telegram Fitness Bot "Сельский Кочка"

## ✅ Функции:
- Кнопка "Полный ГАЗ" — звук Ronnie Coleman
- Автопостинг из Google Sheets
- Прогресс по команде

## 🚀 Как запустить на Render:
1. Зарегистрируйся на https://render.com/
2. Создай новый **Web Service**
3. Залей этот ZIP в GitHub
4. В Render укажи команду запуска: `python bot.py`
5. Добавь переменные окружения:
   - TOKEN
   - SHEET_URL
6. Подключи Google Sheets (создай credentials.json и залей в проект)

## ✅ Интеграция с Google Sheets:
- Создай таблицу с постами
- Подключи сервисный аккаунт и скачай credentials.json
- Вставь его в папку проекта

Полный ГАЗ! 🚀
